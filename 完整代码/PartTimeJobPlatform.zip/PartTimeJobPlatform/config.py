#!/usr/bin/python
# -*- coding: utf-8 -*-


DEBUG = False
SQLALCHEMY_TRACK_MODIFICATIONS = True


def main():
    pass


if __name__ == '__main__':
    main()
