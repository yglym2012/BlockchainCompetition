//login page
require(['pc/page/login/main']);


require(['pc/modules/event/happy-3rd-birthday/main']);