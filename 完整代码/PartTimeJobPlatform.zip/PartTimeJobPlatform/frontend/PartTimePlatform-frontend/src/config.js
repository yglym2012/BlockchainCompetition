global.HOST = 'http://211.159.220.170'
global.PORT = '80'