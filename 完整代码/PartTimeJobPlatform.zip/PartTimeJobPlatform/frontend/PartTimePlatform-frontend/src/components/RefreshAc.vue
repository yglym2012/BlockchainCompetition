<template>
</template>

<script>
export default {
    data() {
        this.$router.replace({path:"/acceptedresumes"})
        return {

        }
    }
}
</script>

<style>
</style>