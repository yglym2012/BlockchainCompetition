<template>
  <div id="footer">
    <div class="wrapper">
      <a target="_blank" rel="nofollow">联系我们</a>
      <a target="_blank">互联网公司导航</a>
      <a target="_blank" rel="nofollow">同嘉微博</a>
      <a class="footer_qr" href="javascript:void(0)" rel="nofollow">同嘉微信<i></i></a>
      <div class="copyright">&copy;2016-2017 Tongjia <a target="_blank">京ICP备14023790号-2</a></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'footer'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
   @import '../assets/css/style.css';
   @import '../assets/css/popup.css';
</style>
