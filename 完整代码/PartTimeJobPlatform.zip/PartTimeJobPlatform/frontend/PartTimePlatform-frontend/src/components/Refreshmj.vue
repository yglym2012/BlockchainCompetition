<template>
</template>

<script>
export default {
    data() {
        this.$router.replace({path:"/myjobs", query:{loadagain:true}})
        return {

        }
    }
}
</script>

<style>
</style>